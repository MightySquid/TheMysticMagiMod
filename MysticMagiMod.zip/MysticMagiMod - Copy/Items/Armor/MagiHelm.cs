using Terraria;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ModLoader;
using Terraria.ID;
using static Terraria.ModLoader.ModContent;

namespace MysticMagiMod.Items.Armor
{
    [AutoloadEquip(EquipType.Head)]
    public class MagiHelm : ModItem
    {
        
		public override void SetStaticDefaults()
        {
			base.SetStaticDefaults();
			DisplayName.SetDefault("Magi Hood");
			Tooltip.SetDefault("The standard magi headpiece."
				+ "\n6% increased magic critical strike chance"
				+ "\nincreases maximum mana by 15");
		}
        public override void SetDefaults()
        {
            item.Size = new Vector2(18);
            item.value = Item.sellPrice(silver: 26);
            item.rare = ItemRarityID.Blue;
            item.defense = 3;
        }

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Silk, 10);
            recipe.AddIngredient(ItemID.Ruby, 3);
            recipe.AddIngredient(ItemID.FallenStar, 2);
            recipe.AddTile(86);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }

        public override bool IsArmorSet(Item head, Item body, Item legs)
        {
            return body.type == ItemType<MagiRobes>() && legs.type == ItemType<MagiGreaves>();
        }

        public override void UpdateArmorSet(Player player)
        {
            player.magicDamage += 0.6f;
            player.statManaMax2 += 20;
            player.setBonus = "6% increased magic damage and +20 mana";
        }
    }
}