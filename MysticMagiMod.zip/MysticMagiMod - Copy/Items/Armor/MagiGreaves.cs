using Terraria;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ModLoader;
using Terraria.ID;

namespace MysticMagiMod.Items.Armor
{
    [AutoloadEquip(EquipType.Legs)]
    public class MagiGreaves : ModItem
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();
            DisplayName.SetDefault("Magi Leggings");
            Tooltip.SetDefault("The standard magi leggings."
                + "\nIncreases your magic damage by 5%"
                + "\nand increases your maximum mana by 15");
        }

        public override void SetDefaults()
        {
            item.Size = new Vector2(18);
            item.value = Item.sellPrice(silver: 22);
            item.rare = ItemRarityID.Blue;
            item.defense = 3;
        }

        public override void UpdateEquip(Player player)
        {
			player.statManaMax2 += 15;
			player.magicDamage += 0.05f;
		}


        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Silk, 15);
            recipe.AddIngredient(ItemID.Topaz, 3);
            recipe.AddIngredient(ItemID.Ruby, 3);
            recipe.AddIngredient(ItemID.FallenStar, 3);
            recipe.AddTile(86);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}