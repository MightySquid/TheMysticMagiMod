using Terraria;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ModLoader;
using Terraria.ID;

namespace MysticMagiMod.Items.Armor
{
    [AutoloadEquip(EquipType.Body)]
    public class MagiRobes : ModItem
    {
        public override void SetStaticDefaults() 
        {
			base.SetStaticDefaults();
			DisplayName.SetDefault("Magi Robes");
			Tooltip.SetDefault("The standard magi chestpiece."
				+ "\nDecreases mana usage by 10%"
				+ "\nand increases maximum mana by 20");
		}

        public override void SetDefaults()
        {
            item.Size = new Vector2(18);
            item.value = Item.sellPrice(silver: 24);
            item.rare = ItemRarityID.Blue;
            item.defense = 5;
        }

        public override void UpdateEquip(Player player)
        {
			player.statManaMax2 += 20;
			player.manaCost += -0.1f;
		}

        public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Silk, 20);
            recipe.AddIngredient(ItemID.Ruby, 3);
            recipe.AddIngredient(ItemID.Diamond, 3);
            recipe.AddIngredient(ItemID.Topaz, 3);
            recipe.AddIngredient(ItemID.FallenStar, 4);
            recipe.AddTile(86);
            recipe.SetResult(this);
            recipe.AddRecipe();
        }
    }
}