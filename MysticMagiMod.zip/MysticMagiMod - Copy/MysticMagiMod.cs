using Terraria.ModLoader;

namespace MysticMagiMod
{
	public class MysticMagiMod : Mod
	{
	}
}